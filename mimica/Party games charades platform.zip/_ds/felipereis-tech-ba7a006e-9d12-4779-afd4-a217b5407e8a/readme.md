# HyperFrames Design System

Design system for **HyperFrames** — a card-template library used by a tech content creator ("Tech-Video") to produce UI-component-styled social assets for YouTube, Instagram and TikTok: glowing dark cards (uploads, analytics, onboarding, notifications, product/destination reveals) meant to be screen-recorded or copied into vertical 9:16 comps and animated.

## Sources

- **Uploaded asset**: `uploads/Card Templates - standalone.html` — a bundled HyperFrames export titled "Card Templates: 7 tipos de card, 2 variações de cor cada." This is the primary ground truth for the card component inventory, palette (dark `oklch` neutrals + blue/purple/green/orange glow accents) and copy voice. Extracted markup lives at `scraps/card-template-extracted.html`.
- **GitHub repo**: [felipesdreis/angular-site-portifolio](https://github.com/felipesdreis/angular-site-portifolio) (branch `main`) — a personal dev portfolio, used only as a pattern reference for dark-theme tokens, pill-button and frosted-glass conventions common to tech/dev-creator sites (see `github.md` for exactly what was read). Its own brand (name, logo, green accent) belongs to a different person and was **not** copied into this system — explore the repo directly for more of its patterns if useful.
- Its `DESIGN.md` file describes an unrelated "Rolex Submariner" landing page that doesn't match the shipped Angular app — treated as stale and ignored in favor of the real CSS/HTML.

## Content fundamentals

- **Language**: source copy is Portuguese (pt-BR) with English UI microcopy mixed in (e.g. "Uploading …", "Continue", "Explore Now") — this reflects real tech-creator content that ships bilingual captions. Keep both registers available; don't force everything into one language.
- **Voice**: short, functional, dashboard-like labels rather than marketing prose — "97.23 KB", "Data updated 2h ago", "Increase vs last month". Numbers and metrics do a lot of the talking (large bold percentages).
- **Casing**: sentence case for body copy and card titles; UPPERCASE + wide letter-spacing for small eyebrow/category labels ("HyperFrames · Biblioteca de componentes", ticker items).
- **Emoji**: used sparingly and functionally, not decoratively — a flag emoji next to a destination name ("Dubai 🇦🇪"), never as bullet points or filler.
- **Vibe**: confident, slightly futuristic "UI/tech" energy — the copy reads like real product screenshots (dashboards, checkouts, uploads), not like ad copy.

## Visual foundations

- **Palette**: near-black neutrals built on a single base hue (`oklch(15% 0.02 260)`) with three accent hues layered on top — **blue** (h255, primary/tech), **purple/violet** (h280–320, secondary/highlight), **green** (h150, growth/success). Warm orange/red (h55/h25) appear only for roadmap and destructive-toast accents. Exactly one accent hue per card — cards never mix two accent colors.
- **Backgrounds**: every card sits on a subtle vertical gradient two shades of its own accent hue (`oklch(20% 0.03 H) → oklch(15% 0.03 H)`), never a flat fill. Several cards add a large, softly blurred (`blur(50px)`) glow blob bleeding off the bottom edge — the source of the "glowing" look.
- **Type**: no custom font shipped in source (system `-apple-system` stack only) — substituted with **Inter** (display/body) and **JetBrains Mono** (tags, filenames, ticker, eyebrow labels) as the nearest free equivalents; flagged to the user below.
- **Spacing**: generous internal card padding (26–44px), tight gaps between small chips (8–18px). No visible baseline grid — spacing is per-component, not a strict global scale, though a 4px-derived token scale is provided for consistency going forward.
- **Animation**: no CSS transitions/keyframes in the source cards themselves (they're static template frames meant to be screen-recorded and animated externally in HyperFrames); the referenced portfolio site uses simple `ease` fades and a `pulse-ring` box-shadow animation on hover — those conventions are available on `Button`/`Badge` hover but kept subtle.
- **Hover states**: brighten via `filter: brightness(1.15)` on solid buttons; border + text recolor to the accent on outline chips; no darkening.
- **Press states**: not defined in source; not fabricated.
- **Borders**: 1–1.5px hairline borders in the same hue family as the card, at low opacity (`/ 0.4–0.5`) — borders tint rather than contrast.
- **Shadows**: two systems — (1) large soft ambient **glows** in the accent color behind hero cards (`0 0 90–100px`), and (2) ordinary drop shadows only on small raised elements (file icons: `0 8px 16px`). No shadow on flat card bodies — depth comes from the glow + gradient, not elevation shadow.
- **Glass/blur**: `backdrop-filter: blur(5–10px)` used for two specific cases — buttons/pills placed over photos or video, and a single "glass toast" notification. Never used as a general card background.
- **Corner radii**: large and consistent — 20–28px on cards, full pill (999px) on buttons/switches/badges, 6–8px on small chips/icons.
- **Cards**: no visible box-shadow elevation; identity comes from gradient + hairline border + accent glow, as above.
- **Imagery**: only the "destination/product" card family uses photography (full-bleed, dark gradient scrim at the bottom for text legibility). No illustration style present.

## Iconography

No icon font, SVG icon set, or PNG icon sprite exists in the source — glyphs are plain **unicode symbols** (✕ close, ✓ check, → / ↗ arrows, ◆ separator, ▾ chevron) sized with regular text. Emoji are used only for a small set of literal meanings (flags). If a consuming project needs a broader icon set, the closest same-weight CDN match is **Lucide** — flag any addition as a substitution.

## Font substitution — please confirm

No webfont files or `@font-face` rules were found in either source (the card templates use only the system font stack; the portfolio loads Roboto/Roboto Mono from Google Fonts with no local files). This system ships **Inter** + **JetBrains Mono** via Google Fonts as the nearest modern, geometric, tech-flavored substitutes (`tokens/fonts.css`). If you have real brand font files, send them over and this will be swapped.

## Components

`components/core/` — primitives composed into the cards below:
- **Button** — solid gradient CTA / glass (blurred, for use over photos) / ghost nav pill
- **Badge** — tag (mono chip) / pill (outline, fills on hover) / ticker (bare tracked label)
- **ProgressBar** — slim rounded progress track
- **Toggle** — pill switch
- **IconTile** — file-type icon (with extension label) or plain tool swatch

`components/cards/` — the 7 card families from the source asset, 2 color variants each:
- **UploadCard** — file upload/processing progress
- **AnalyticsCard** — stat + sparkline
- **ToolCard** — small "my stack" tile (bordered-glow or mono variant)
- **TimelineCard** — vertical roadmap with connector rail
- **StepperCard** — onboarding step rail over a form panel
- **ToastCard** — notification list or single glass toast
- **DestinationCard** — full-bleed photo card with gradient scrim

### Intentional additions
None of the above were invented — every component and every prop-level variant traces to a card or interactive element actually present in the uploaded asset or the reference portfolio (buttons, pills, tags, switches, file icons). `IconTile` was factored out as a shared primitive because the same "colored swatch with a label" shape recurs across the Upload and Tool cards.

## UI kits

`ui_kits/card-studio/` — **Card Studio**, a direct recreation of the uploaded `Card Templates - standalone.html` gallery: all 7 sections × 2 variants, composed from the components above, with a cosmetic "Copy card" hover affordance mirroring the original tool's copy-into-your-comp workflow.

## Index

- `styles.css` — root stylesheet; imports everything under `tokens/`
- `tokens/colors.css`, `typography.css`, `spacing.css`, `effects.css`, `fonts.css` — design tokens
- `components/core/` — Button, Badge, ProgressBar, Toggle, IconTile (+ `core.card.html` showcase)
- `components/cards/` — UploadCard, AnalyticsCard, ToolCard, TimelineCard, StepperCard, ToastCard, DestinationCard (+ `cards.card.html` showcase)
- `ui_kits/card-studio/` — Card Studio gallery screen (`index.html`, `App.jsx`)
- `guidelines/` — foundation specimen cards (colors, type, spacing, brand/glass/iconography)
- `assets/image-slot.js` — drag-and-drop image placeholder used by DestinationCard
- `scraps/card-template-extracted.html` — raw markup extracted from the uploaded bundle, kept for reference
- `github.md` — source-repo sync record
- `SKILL.md` — Claude Code-compatible skill wrapper

## Caveats & ask

- **No logo exists** for this brand in either source — nothing was drawn. Wherever a mark would go, the plain name "HyperFrames" is set in type instead. If there's a real logo, send it over.
- **Fonts are a substitution** (Inter + JetBrains Mono in place of the system-font-only source) — confirmed above; swap in real files if you have them.
- The GitHub portfolio repo belongs to a different person's personal brand and was used only for pattern research, not asset copying — say the word if you'd like a couple of its dev-portfolio patterns (nav, ticker, project grid) pulled into a components group of their own.
- This system currently covers only the **card-template** product surface from your upload. If "Tech-Video" has other surfaces (a channel banner, thumbnail template, intro/outro slate) send those over and they can become their own UI kit or slide set.

Iterate with me — tell me what's off and I'll refine colors, add missing card variants, or wire up real fonts/logo.
